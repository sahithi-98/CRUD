package com.cg.dao;

import java.util.List;

import com.cg.model.Product;

public interface ProductDao {

	boolean save(Product product);

	boolean delete(int pid);

	boolean update(Product product);

	Product getById(int pid);

	List<Product> getAllproducts();

}
