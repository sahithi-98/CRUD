package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Product {
	
	@Id
	@GeneratedValue(generator="ss",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="ss",sequenceName="ss",initialValue=100,allocationSize=1)
	
	private int pid;
	@NotNull(message="ProductName must be entered")
	@Pattern(regexp="[A-Za-z0-9._]", message="name should be alphanumeric")
	@Size(min=6, message="pname should be min 6 chars")
	private String pname;
	@NotNull(message = "Description must be entered")
	private String description;
	@NotNull(message= "product must be entered")
	@Min(value=100, message="price should be > 100")
	private double price;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Product(int pid, String pname, String description, double price) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.description = description;
		this.price = price;
	}

	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", description=" + description + ", price=" + price + "]";
	}
	
	

}
